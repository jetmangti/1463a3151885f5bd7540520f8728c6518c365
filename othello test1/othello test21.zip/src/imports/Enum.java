package imports;

public class Enum 
{
	public enum Team{
		BLACK,WHITE,EMPTY,BLACK_FR,WHITE_FR
	}
	public enum Calc{
		WHITE,BLACK
	}
}

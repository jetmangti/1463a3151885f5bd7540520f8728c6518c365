import javax.swing.JFrame;

public interface window {
	public void setFrame(JFrame frame);
	//public void ();

}


public interface AIInterface 
{
	public Cell doJob();
}
